/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author lucas
 */
public class Util {
     public static void habilitar(boolean valor, JComponent ... vetVal) {
        for (int i = 0; i < vetVal.length; i++) {
                vetVal[i].setEnabled(valor);
            
        }
  
    }
    
    public static void LimparCampo(JComponent ... vetLCampo) {
        for (int i = 0; i < vetLCampo.length; i++) {
             ((JTextField)vetLCampo[i]).setText("");
            
        }
    }
    
    public static void msg(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem);
      }
    public static int perguntar(String mensagem, String perguntar) {
        return JOptionPane.showConfirmDialog(null, mensagem, perguntar, JOptionPane.YES_NO_OPTION);
    }
    
    public static int StrInt(String cad) {
        return 0;
    }
    
    public static String IntStr(int num) {
        return "";
    }
    
    public static double StrDouble(String cad) {
      return 0;  
    }
    
    public static String DoubleStr(String num) {
        return "";
    }
    
    public static Date StrData(String cad) {
        return null;
    }
    
    public static String DataStr(String data) {
        return "";
    }
    
}
